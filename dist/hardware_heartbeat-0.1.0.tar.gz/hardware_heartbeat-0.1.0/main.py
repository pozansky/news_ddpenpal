def main():
    print("Hello from mcppythonproject3!")


if __name__ == "__main__":
    main()
